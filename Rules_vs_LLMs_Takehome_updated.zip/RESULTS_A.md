# Project A — Results

## Offline rule-engine measurements

The test fixture contains 200 pure-salary cases (two assessment years, 100 salary points each), with expected outputs from a separate oracle implementation. Each deterministic path was run ten times per regime and case.

| Path | Exact comparisons | Rupee-exact accuracy | 10-run deterministic | Median latency | p95 latency | API cost / 1,000 |
|---|---:|---:|---|---:|---:|---:|
| Hand-coded rules | 400/400 | 100.0% | True | 0.01661 ms | 0.02182 ms | $0 direct API |
| Compiled configuration | 400/400 | 100.0% | True | 0.01635 ms | 0.02145 ms | $0 direct API |
| Query-time Gemini | No response (API request timed out) | Not measured | Not measured | Not measured | Not measured | Not measured |

## Official calculator cross-check

Checked 30 taxable-income values in the official Advanced Calculator for AY 2025-26, both regimes (60 outputs total). **49 matched exactly; 11 differed by ₹1–₹2.** The test records the discrepancy cases. See [`project_a/official_validation.md`](project_a/official_validation.md) for inputs and the rounding difference.

## FY 2025-26 change log

| Item | Hand-coded rules | Compiled configuration |
|---|---|---|
| Change made | Added AY 2026-27 new-regime slabs, standard deduction and Section 87A rebate parameters | Added corresponding versioned values in JSON |
| Time to make change | Not tracked | Not tracked |
| What broke in automated fixture | None observed | None observed |
| Silent failures found | None observed in the pure-salary fixtures; no claim about untested legal cases | None observed in fixtures; configuration is not LLM-generated |

## Validation limits

- The 200-case fixture covers pure salary and threshold boundaries and matches a separate local oracle. The official portal comparison found the recorded rounding differences; these need a legal decision before production.
- HRA and deductions have only smoke-level coverage. Detailed values, surcharge edge cases, statutory rounding and 80D combinations still need more official comparisons.
- Query-time Gemini is implemented, but no model response was obtained: the API smoke request timed out from the provided execution environment. Accuracy, latency, usage, cost and repeatability remain unknown. `scripts/benchmark_gemini.py` provides a 100-call sequential experiment for a network-enabled environment. The rule compiler writes a pending candidate; the checked-in configuration is manually reviewed, not LLM-generated.
- FY 2025-26 changes are represented in the second versioned configuration (AY 2026-27). No wall-clock implementation/change time was tracked and the run has not been subjected to adversarial requirements changes.

## Final architecture proposal

Use a parser/LLM hybrid only for extracting user facts: return required clarification questions for missing age, residence, or deduction facts. Run tax arithmetic in versioned deterministic code, with clause IDs attached to every line item before production. Keep the model out of tax arithmetic. Every budget update should arrive as a reviewed, diffable rules file, pass boundary fixtures and official-calculator comparisons, then deploy behind a versioned effective date.

## Sources

- [Income Tax Department calculator](https://www.incometax.gov.in/iec/foportal/income-tax-calculator?mobile-app=1)
- [Income Tax Department tax rates and computation](https://wm.incometax.gov.in/w/tax-rates-and-computation)
- [Finance Act 2024](https://www.incometaxindia.gov.in/w/section-1-132)
- [Finance Act 2025 amendment to section 115BAC](https://wmstatic-prd.incometaxindia.gov.in/web/guest/w/section-37-113)
