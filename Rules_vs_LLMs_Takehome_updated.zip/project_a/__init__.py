"""Income-tax prototype."""
