"""Deterministic salary-only income tax engine for AY 2025-26 and AY 2026-27.

The tables below are explicit, versioned configuration. Computation uses whole rupees.
"""
from dataclasses import dataclass, field
from typing import Literal

Regime = Literal["old", "new"]


@dataclass(frozen=True)
class Taxpayer:
    gross_salary: int
    age: int = 30
    resident: bool = True
    # Old-regime HRA facts. `hra_salary` is basic + eligible DA for HRA purposes.
    hra_received: int = 0
    rent_paid: int = 0
    hra_salary: int = 0
    metro: bool = False
    section_80c: int = 0
    section_80ccd_1b: int = 0
    medical_self: int = 0
    medical_self_age_60: bool = False
    medical_parents: int = 0
    parent_age_60: bool = False
    home_loan_interest: int = 0


@dataclass(frozen=True)
class Result:
    regime: Regime
    assessment_year: str
    gross_salary: int
    standard_deduction: int
    hra_exemption: int
    other_deductions: int
    taxable_income: int
    slab_tax: int
    rebate: int
    surcharge: int
    cess: int
    total_tax: int
    reasons: tuple[str, ...] = field(default_factory=tuple)
    deduction_breakdown: tuple[str, ...] = field(default_factory=tuple)


RULES = {
    "AY2025-26": {
        "new_slabs": [(300_000, 0), (700_000, .05), (1_000_000, .10), (1_200_000, .15), (1_500_000, .20), (None, .30)],
        "new_standard": 75_000, "new_rebate_limit": 700_000, "new_rebate_cap": 25_000,
        "new_rebate_marginal": True,
    },
    "AY2026-27": {
        "new_slabs": [(400_000, 0), (800_000, .05), (1_200_000, .10), (1_600_000, .15), (2_000_000, .20), (2_400_000, .25), (None, .30)],
        "new_standard": 75_000, "new_rebate_limit": 1_200_000, "new_rebate_cap": 60_000,
        "new_rebate_marginal": True,
    },
}
OLD_SLABS_NON_SENIOR = [(250_000, 0), (500_000, .05), (1_000_000, .20), (None, .30)]
OLD_SLABS_SENIOR = [(300_000, 0), (500_000, .05), (1_000_000, .20), (None, .30)]
OLD_SLABS_SUPER_SENIOR = [(500_000, 0), (1_000_000, .20), (None, .30)]


def _round10(n: int) -> int:
    return ((n + 5) // 10) * 10


def _slab_tax(income: int, slabs: list[tuple[int | None, float]]) -> int:
    tax, lower = 0.0, 0
    for upper, rate in slabs:
        taxable = max(0, (income if upper is None else min(income, upper)) - lower)
        tax += taxable * rate
        if upper is None or income <= upper:
            break
        lower = upper
    return int(tax + .5)


def _surcharge(income: int, base_tax: int, regime: Regime, slabs: list[tuple[int | None, float]]) -> int:
    # Ordinary income rates; special-rate income is outside this engine.
    if income <= 5_000_000:
        return 0
    if income <= 10_000_000:
        rate = .10
    elif income <= 20_000_000:
        rate = .15
    elif regime == "new" or income <= 50_000_000:
        rate = .25
    else:
        rate = .37
    raw = int(base_tax * rate + .5)
    # Marginal relief: total tax plus surcharge may not exceed tax at threshold + excess income.
    threshold = 5_000_000 if income <= 10_000_000 else 10_000_000 if income <= 20_000_000 else 20_000_000 if regime == "new" or income <= 50_000_000 else 50_000_000
    threshold_rate = .10 if threshold == 5_000_000 else .15 if threshold == 10_000_000 else .25 if threshold == 20_000_000 else .37
    threshold_tax = _slab_tax(threshold, slabs)
    threshold_surcharge = int(threshold_tax * threshold_rate + .5)
    max_total = threshold_tax + threshold_surcharge + (income - threshold)
    return max(0, min(raw, max_total - base_tax))


def _deductions(person: Taxpayer) -> tuple[int, int, tuple[str, ...]]:
    hra = min(person.hra_received, max(0, person.rent_paid - int(.10 * person.hra_salary)), int((.50 if person.metro else .40) * person.hra_salary))
    c80 = min(max(0, person.section_80c), 150_000)
    nps = min(max(0, person.section_80ccd_1b), 50_000)
    self_cap = 50_000 if person.medical_self_age_60 else 25_000
    parent_cap = 50_000 if person.parent_age_60 else 25_000
    self_medical = min(max(0, person.medical_self), self_cap)
    parent_medical = min(max(0, person.medical_parents), parent_cap)
    medical = self_medical + parent_medical
    home = min(max(0, person.home_loan_interest), 200_000)
    breakdown=(f"Section 80C: ₹{c80:,} (cap ₹1,50,000)", f"Section 80CCD(1B): ₹{nps:,} (cap ₹50,000)", f"Section 80D self/family: ₹{self_medical:,} (age-based cap ₹{self_cap:,})", f"Section 80D parents: ₹{parent_medical:,} (age-based cap ₹{parent_cap:,})", f"Section 24(b) self-occupied home-loan interest: ₹{home:,} (cap ₹2,00,000; eligibility assumed)")
    return hra, c80 + nps + medical + home, breakdown


def calculate(person: Taxpayer, regime: Regime, assessment_year: str = "AY2025-26", rules: dict | None = None) -> Result:
    if assessment_year not in RULES:
        raise ValueError(f"Unsupported assessment year: {assessment_year}")
    if person.gross_salary < 0 or person.age < 0:
        raise ValueError("Salary and age must be non-negative")
    cfg = (rules or RULES)[assessment_year]
    standard = min(person.gross_salary, 50_000 if regime == "old" else cfg["new_standard"])
    if regime == "old":
        hra, deductions, deduction_breakdown = _deductions(person)
        raw_income = max(0, person.gross_salary - standard - hra - deductions)
        slabs = OLD_SLABS_SUPER_SENIOR if person.age >= 80 else OLD_SLABS_SENIOR if person.age >= 60 else OLD_SLABS_NON_SENIOR
        rebate_limit, rebate_cap = 500_000, 12_500
        marginal_rebate = False
    elif regime == "new":
        hra, deductions, deduction_breakdown = 0, 0, ()
        raw_income = max(0, person.gross_salary - standard)
        slabs = cfg["new_slabs"]
        rebate_limit, rebate_cap = cfg["new_rebate_limit"], cfg["new_rebate_cap"]
        marginal_rebate = cfg["new_rebate_marginal"]
    else:
        raise ValueError("regime must be 'old' or 'new'")
    taxable = _round10(raw_income)
    tax = _slab_tax(taxable, slabs)
    rebate = 0
    # Rebate eligibility is tested on computed total income before section 288A tax rounding.
    if person.resident and raw_income <= rebate_limit:
        rebate = min(tax, rebate_cap)
    elif person.resident and marginal_rebate and raw_income > rebate_limit:
        # Rebate is capped so tax after rebate does not exceed income above threshold.
        rebate = min(rebate_cap, max(0, tax - (raw_income - rebate_limit)))
    after_rebate = max(0, tax - rebate)
    surcharge = _surcharge(taxable, after_rebate, regime, slabs)
    cess = int((after_rebate + surcharge) * .04 + .5)
    total = _round10(after_rebate + surcharge + cess)
    reasons = [f"Salary income: ₹{person.gross_salary:,}.", f"Section 16(ia) standard deduction: ₹{standard:,}.", f"Taxable income rounded to nearest ₹10 under section 288A: ₹{taxable:,}.", f"Slab tax under the applicable Finance Act schedule: ₹{tax:,}.", f"Section 87A rebate: ₹{rebate:,}; applicable surcharge: ₹{surcharge:,}; 4% health and education cess: ₹{cess:,}; final tax rounded under section 288B: ₹{total:,}."]
    if regime == "old":
        reasons.extend([f"Section 10(13A) HRA exemption, least of actual HRA, rent less 10% of eligible salary, and 40%/50% of eligible salary: ₹{hra:,}.", f"Total eligible deductions under Chapter VI-A and section 24(b): ₹{deductions:,}."])
    return Result(regime, assessment_year, person.gross_salary, standard, hra, deductions, taxable, tax, rebate, surcharge, cess, total, tuple(reasons), deduction_breakdown)


def compare(person: Taxpayer, assessment_year: str = "AY2025-26", rules: dict | None = None) -> dict:
    old, new = calculate(person, "old", assessment_year, rules), calculate(person, "new", assessment_year, rules)
    return {"old": old, "new": new, "recommended": "old" if old.total_tax < new.total_tax else "new" if new.total_tax < old.total_tax else "tie"}
