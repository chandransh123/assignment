"""Three experiment paths: deterministic, query-time Gemini, compiled configuration."""
import json
from pathlib import Path
from dataclasses import asdict
from .llm import gemini_json, llm_compiled_rules
from .parser import parse_description
from .tax import RULES, calculate, compare

RULE_TEXT = """India salary-only tax rules. AY2025-26 / FY2024-25: old-regime rates apply under section 115BAC opt-out; new-regime slabs are 0-3L 0%, 3-7L 5%, 7-10L 10%, 10-12L 15%, 12-15L 20%, above 15L 30%; standard deduction 75,000 in new regime, 50,000 old. Section 87A resident rebate: old total income <=5L, max 12,500; new <=7L, max 25,000 with marginal relief above threshold. AY2026-27 / FY2025-26 new slabs: 0-4L 0%, 4-8L 5%, 8-12L 10%, 12-16L 15%, 16-20L 20%, 20-24L 25%, above 24L 30%; new section 87A limit 12L, maximum 60,000 with marginal relief; standard deduction 75,000. Cess is 4%; surcharge thresholds and marginal relief are applied by the deterministic implementation. Old regime permits HRA least-of-three exemption, section 80C cap 1.5L, 80CCD(1B) cap 50,000, 80D age-sensitive premiums, self-occupied home-loan interest cap 2L. New regime excludes those deductions."""

def _compiled(path=None):
    path=Path(path or Path(__file__).with_name("compiled_rules.json"))
    data=json.loads(path.read_text())
    if set(data)!=set(RULES): raise ValueError("Compiled rules must define both supported assessment years")
    for year, config in data.items():
        if not isinstance(config.get("new_slabs"),list) or not isinstance(config.get("new_standard"),int):
            raise ValueError("Compiled rule file failed schema review")
        if not isinstance(config.get("new_rebate_limit"),int) or not isinstance(config.get("new_rebate_cap"),int):
            raise ValueError("Compiled rule file failed rebate validation")
        if not config["new_slabs"] or config["new_slabs"][-1][0] is not None:
            raise ValueError("Compiled slabs need an open-ended final band")
        previous=0
        for upper,rate in config["new_slabs"]:
            if not isinstance(rate,(int,float)) or not 0<=rate<=1 or (upper is not None and (not isinstance(upper,int) or upper<=previous)):
                raise ValueError("Compiled slab boundaries/rates failed validation")
            if upper is not None: previous=upper
    return {year:{**cfg,"new_slabs":[tuple(x) for x in cfg["new_slabs"]]} for year,cfg in data.items()}

def handcoded(description: str, year="AY2025-26") -> dict:
    parsed=parse_description(description)
    if parsed.questions:return {"questions":list(parsed.questions)}
    return {"parsed":asdict(parsed.taxpayer),"tax":compare(parsed.taxpayer,year)}

def query_time(description: str, year="AY2025-26") -> tuple[dict,float]:
    # The LLM is asked to both extract facts and compute from the provided legal summary per request.
    prompt=(f"Year={year}. Use only the rules below. Parse the user's salary, age, residency and deduction facts. "
            "If a fact needed for the tax comparison is missing or contradictory, return a non-empty questions array and do not guess. "
            "Otherwise return questions as an empty array, annual_gross_salary as an integer, age as an integer, resident as a boolean, "
            "old_tax and new_tax as integer total rupees, and recommended as old, new, or tie. "
            "Do not include markdown. Rules="+RULE_TEXT+" User="+description)
    return gemini_json(prompt)

def compiled_rules(description: str, year="AY2025-26", path=None) -> dict:
    parsed=parse_description(description)
    if parsed.questions:return {"questions":list(parsed.questions)}
    return {"parsed":asdict(parsed.taxpayer),"tax":compare(parsed.taxpayer,year,_compiled(path))}

def compile_candidate(rule_text: str, destination: str) -> tuple[str,float]:
    """Produce a pending candidate only. The operator must review and explicitly install it."""
    candidate,latency=llm_compiled_rules(rule_text)
    # Require both supported years and expected keys, then leave the candidate inactive.
    for year in RULES:
        cfg=candidate.get(year)
        if not isinstance(cfg,dict) or "new_slabs" not in cfg or "new_rebate_limit" not in cfg:
            raise ValueError(f"LLM candidate missing required rule fields for {year}")
    Path(destination).write_text(json.dumps(candidate,indent=2))
    return destination,latency
