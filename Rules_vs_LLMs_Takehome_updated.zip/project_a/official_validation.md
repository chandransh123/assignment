# Official calculator cross-check

**Source:** Income Tax Department, [Income and Tax Calculator](https://www.incometax.gov.in/iec/foportal/income-tax-calculator?mobile-app=1), e-Filing portal, Advanced Calculator. Checked 24 November 2026.

## Method

- Assessment year: AY 2025-26 (FY 2024-25), Income-tax Act 1961.
- 30 distinct taxable-income amounts are saved in `official_calculator_checks.csv`; both old and new regimes were checked, for 60 total outputs.
- For each target taxable income `x`, the Advanced Calculator salary was `x + ₹50,000` in the old regime or `x + ₹75,000` in the new regime. This made its standard deduction produce the target taxable income. Age was below 60, residence was resident, and no other income, exemption, or deduction was entered.
- Recorded “Total Tax on Income”, before late-filing fees and interest. The calculator was in Advanced mode, which displays Section 87A marginal relief. The Basic Calculator omits the marginal-relief adjustment and was not used for the final comparison.

## Result

The deterministic engine matched **49 of 60** displayed amounts exactly. Eleven amounts differ by ₹1 or ₹2. Every difference is recorded by the regression test and comes from taxable-income/tax rounding at values ending in 9, plus the ₹7,00,001 marginal-relief boundary. The portal appears to calculate those inputs using unrounded values, while the engine applies the statutory rounding provisions. The online calculator also states that it is a quick estimate and may not give a correct result in every circumstance. This difference needs a legal review before production; it is not silently counted as a pass.

The 200 generated fixtures remain separate: they compare the code to an independent local oracle and cover pure-salary amounts under both AY 2025-26 and AY 2026-27. They are not official-calculator observations.
