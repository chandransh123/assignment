"""Measure query-time Gemini tax answers on 10 controlled inputs, 10 repeats each.

Run with GEMINI_API_KEY set in the shell. The key is read only from the environment
and is never written to the report. Requests are sequential to respect free-tier limits.
"""
import json
import os
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from project_a.approaches import query_time
from project_a.tax import Taxpayer, compare

CASES = [
    ("Annual gross salary Rs 450000; age 31; resident India; no deductions.", 450_000, 31),
    ("Annual salary Rs 625000; age 45; resident India; no deductions.", 625_000, 45),
    ("My gross salary per year is Rs 700000, age 29, resident India, no deductions.", 700_000, 29),
    ("Salary Rs 775000 yearly; age 58; resident India; no deductions.", 775_000, 58),
    ("Annual income from salary is Rs 1190000; age 35; resident India; no deductions.", 1_190_000, 35),
    ("I receive Rs 1275000 annual salary. Age 40. Resident India. No deductions.", 1_275_000, 40),
    ("Annual gross salary Rs 1490000; age 62; resident India; no deductions.", 1_490_000, 62),
    ("Salary is Rs 1600000 a year; age 52; resident India; no deductions.", 1_600_000, 52),
    ("Annual gross salary Rs 2450000; age 33; resident India; no deductions.", 2_450_000, 33),
    ("Salary Rs 5100000 per year; age 67; resident India; no deductions.", 5_100_000, 67),
]
REPEATS = 10


def _usage_tokens(usage, names):
    if not isinstance(usage, dict):
        return None
    for name in names:
        value = usage.get(name)
        if isinstance(value, (int, float)):
            return int(value)
    return None


def _tax_pair(output):
    if not isinstance(output, dict) or output.get("questions"):
        return None
    old, new = output.get("old_tax"), output.get("new_tax")
    if old is None or new is None:
        nested = output.get("tax")
        if isinstance(nested, dict):
            old, new = nested.get("old_tax"), nested.get("new_tax")
    try:
        return int(old), int(new)
    except (TypeError, ValueError):
        return None


def run():
    if not os.getenv("GEMINI_API_KEY"):
        raise SystemExit("Set GEMINI_API_KEY in the environment; do not put it in a project file.")
    records, input_tokens, output_tokens = [], 0, 0
    usage_complete = True
    for case_index, (description, salary, age) in enumerate(CASES, 1):
        expected = compare(Taxpayer(gross_salary=salary, age=age, resident=True), "AY2025-26")
        expected_pair = (expected["old"].total_tax, expected["new"].total_tax)
        outputs, latencies = [], []
        for repeat in range(1, REPEATS + 1):
            started = time.perf_counter()
            result, api_latency = query_time(description, "AY2025-26")
            elapsed = time.perf_counter() - started
            pair = _tax_pair(result)
            outputs.append(pair)
            latencies.append(api_latency if api_latency is not None else elapsed)
            usage = result.get("_usage") if isinstance(result, dict) else None
            in_count = _usage_tokens(usage, ("total_input_tokens", "input_tokens", "prompt_token_count"))
            out_count = _usage_tokens(usage, ("total_output_tokens", "output_tokens", "candidates_token_count"))
            if in_count is None or out_count is None:
                usage_complete = False
            else:
                input_tokens += in_count
                output_tokens += out_count
            records.append({"case": case_index, "repeat": repeat, "description": description,
                            "expected_old_tax": expected_pair[0], "expected_new_tax": expected_pair[1],
                            "predicted_old_tax": pair[0] if pair else None,
                            "predicted_new_tax": pair[1] if pair else None,
                            "exact_both_regimes": pair == expected_pair,
                            "latency_seconds": round(latencies[-1], 4), "usage": usage})
            # Incremental checkpoint preserves completed observations if a quota is hit.
            (ROOT / "results" / "gemini_project_a_runs.json").write_text(json.dumps(records, indent=2))
        valid = [x for x in outputs if x is not None]
        records.append({"case_summary": case_index,
                        "exact_both_regimes": sum(x == expected_pair for x in outputs),
                        "repeats": REPEATS,
                        "deterministic_output": len(set(outputs)) == 1,
                        "median_latency_seconds": round(statistics.median(latencies), 4),
                        "expected_pair": expected_pair,
                        "valid_responses": len(valid)})
    model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    price_in = float(os.getenv("GEMINI_INPUT_USD_PER_MILLION", "0.75"))
    price_out = float(os.getenv("GEMINI_OUTPUT_USD_PER_MILLION", "3.75"))
    paid_estimate = ((input_tokens * price_in) + (output_tokens * price_out)) / 1_000_000 if usage_complete else None
    report = {"assessment_year": "AY2025-26", "model": model, "cases": len(CASES), "repeats_per_case": REPEATS,
              "calls": len(CASES) * REPEATS,
              "exact_answers": sum(bool(x.get("exact_both_regimes")) for x in records if "repeat" in x),
              "total_answers": len(CASES) * REPEATS,
              "deterministic_cases": sum(bool(x.get("deterministic_output")) for x in records if "case_summary" in x),
              "input_tokens": input_tokens if usage_complete else None,
              "output_tokens": output_tokens if usage_complete else None,
              "estimated_paid_cost_usd": round(paid_estimate, 8) if paid_estimate is not None else None,
              "estimated_paid_cost_per_1000_requests_usd": round(paid_estimate * 1000 / (len(CASES) * REPEATS), 6) if paid_estimate is not None else None,
              "price_usd_per_million_tokens": {"input": price_in, "output": price_out},
              "note": "Paid estimate uses configured list prices. Free-tier charges are zero only when the account confirms these calls are covered by its free quota."}
    (ROOT / "results" / "gemini_project_a_summary.json").write_text(json.dumps(report, indent=2))
    return report


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
