"""Download all calendar-year 2023 NYC 311 rows and save source provenance."""
import argparse, csv, json
from datetime import datetime, timezone
from pathlib import Path
from project_b.data import fetch_all_2023

def main():
    parser=argparse.ArgumentParser(); parser.add_argument("--out",default="data/nyc_311_2023.csv"); args=parser.parse_args()
    rows=fetch_all_2023()
    if not rows: raise SystemExit("No NYC rows returned")
    path=Path(args.out); path.parent.mkdir(parents=True,exist_ok=True)
    columns=sorted({key for row in rows for key in row})
    with path.open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction="ignore"); writer.writeheader(); writer.writerows(rows)
    metadata={"dataset_id":"erm2-nwe9","query":"created_date >= 2023-01-01 and created_date < 2024-01-01","retrieved_at_utc":datetime.now(timezone.utc).isoformat(),"rows":len(rows),"csv":str(path)}
    path.with_suffix(".metadata.json").write_text(json.dumps(metadata,indent=2))
    print(json.dumps(metadata,indent=2))
if __name__=="__main__":main()
