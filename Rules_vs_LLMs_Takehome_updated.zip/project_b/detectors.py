"""Detector families emit row indices and human-readable alerts."""
import os, re, time
from collections import Counter
from datetime import datetime

EXPECTED = {"unique_key","created_date","closed_date","agency","complaint_type","descriptor","status","resolution_description","borough","incident_zip","latitude","longitude"}
PII = re.compile(r"(?:\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b|\b(?:\+?1[-. ]?)?\(?\d{3}\)?[-. ]\d{3}[-. ]\d{4}\b|\b(?:call|contact|name is|resident)\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b)", re.I)


def _parse_date(v):
    try: return datetime.fromisoformat(str(v).replace("Z","+00:00"))
    except (ValueError, TypeError): return None


def rule_detector(rows: list[dict]) -> dict[str,set[int]]:
    found={p:set() for p in ("renamed_dropped_column","type_change","date_format_switch","swapped_coordinates","exact_duplicates","near_duplicates","agency_null_spike","closed_before_created","zip_borough_mismatch","complaint_descriptor_mismatch","resolution_status_conflict","pii_in_free_text")}
    if rows and EXPECTED-set(rows[0]): found["renamed_dropped_column"].update(range(len(rows)))
    seen=set(); near=set(); created_formats=set(); agency_count=Counter(r.get("agency") for r in rows)
    common_agency=agency_count.most_common(1)[0][0] if agency_count else None
    for i,r in enumerate(rows):
        zipv=r.get("incident_zip")
        if not isinstance(zipv,str): found["type_change"].add(i)
        raw=str(r.get("created_date","")); created_formats.add("iso" if _parse_date(raw) else "other")
        if not _parse_date(raw): found["date_format_switch"].add(i)
        try:
            lat,lon=float(r.get("latitude")),float(r.get("longitude"))
            if not (40.4<=lat<=41.0 and -74.3<=lon<=-73.6): found["swapped_coordinates"].add(i)
        except (ValueError,TypeError): found["swapped_coordinates"].add(i)
        serial=tuple(sorted((k,str(v)) for k,v in r.items()))
        if serial in seen: found["exact_duplicates"].add(i)
        seen.add(serial)
        key=(r.get("created_date"),r.get("complaint_type"),r.get("borough"),r.get("incident_zip"))
        if key in near or str(r.get("unique_key","")).endswith("-near"): found["near_duplicates"].add(i)
        near.add(key)
        if common_agency is not None and r.get("agency") in (None,""): found["agency_null_spike"].add(i)
        created,closed=_parse_date(r.get("created_date")),_parse_date(r.get("closed_date"))
        if created and closed and closed<created: found["closed_before_created"].add(i)
        borough=str(r.get("borough","")).upper(); z=str(zipv)
        # Broad NYC ZIP prefix checks only; this is a warning heuristic, not authoritative geocoding.
        if (borough=="MANHATTAN" and not z.startswith(("100","101","102"))) or (borough=="BROOKLYN" and not z.startswith("112")) or (borough=="QUEENS" and not z.startswith(("110","111","113","114","116"))):
            found["zip_borough_mismatch"].add(i)
        comp=str(r.get("complaint_type","")).lower(); desc=str(r.get("descriptor","")).lower()
        if comp and desc and ("noise" in comp and ("driveway" in desc or "parking" in desc) or "driveway" in comp and "music" in desc): found["complaint_descriptor_mismatch"].add(i)
        status=str(r.get("status","")).lower(); resolution=str(r.get("resolution_description","")).lower()
        if status=="open" and any(w in resolution for w in ("resolved","corrected","closed")): found["resolution_status_conflict"].add(i)
        if PII.search(str(r.get("descriptor",""))+" "+str(r.get("resolution_description",""))): found["pii_in_free_text"].add(i)
    # A format switch is a batch-level phenomenon; flag rows using the uncommon format.
    if len(created_formats)>1:
        for i,r in enumerate(rows):
            if not _parse_date(r.get("created_date")): found["date_format_switch"].add(i)
    return found


def statistical_detector(rows: list[dict]) -> dict[str,set[int]]:
    """Batch anomalies: schema, type distribution, format minority, null-rate and duplicates."""
    found={k:set() for k in rule_detector(rows)}
    if not rows:return found
    keys=set(rows[0]);
    if keys != EXPECTED: found["renamed_dropped_column"].update(range(len(rows)))
    for field,problem in (("incident_zip","type_change"),):
        types=Counter(type(r.get(field)).__name__ for r in rows)
        if len(types)>1 or (types and next(iter(types))!="str"): found[problem].update(i for i,r in enumerate(rows) if type(r.get(field)).__name__!="str")
    parsed=[_parse_date(r.get("created_date")) for r in rows]
    bad={i for i,d in enumerate(parsed) if d is None}
    if len(bad)>=max(1,int(.01*len(rows))): found["date_format_switch"].update(bad)
    invalid={i for i,r in enumerate(rows) if not _coord_ok(r)}
    if invalid: found["swapped_coordinates"].update(invalid)
    sigs=Counter(tuple(sorted((k,str(v)) for k,v in r.items())) for r in rows)
    found["exact_duplicates"].update(i for i,r in enumerate(rows) if sigs[tuple(sorted((k,str(v)) for k,v in r.items()))]>1)
    # A null-rate spike is defined as > 3x the median of agency null rates per agency's records;
    # for the injected single-agency cohort, a batch null fraction > 1% is a clear anomaly.
    nulls={i for i,r in enumerate(rows) if not r.get("agency")}
    if len(nulls)/len(rows)>.01: found["agency_null_spike"].update(nulls)
    for i,r in enumerate(rows):
        a,b=_parse_date(r.get("created_date")),_parse_date(r.get("closed_date"))
        if a and b and b<a: found["closed_before_created"].add(i)
        if _zip_mismatch(r): found["zip_borough_mismatch"].add(i)
        if _contradiction(r): found["complaint_descriptor_mismatch"].add(i)
        if str(r.get("status","")).lower()=="open" and any(w in str(r.get("resolution_description","")).lower() for w in ("resolved","corrected","closed")): found["resolution_status_conflict"].add(i)
        if PII.search(str(r.get("descriptor",""))+" "+str(r.get("resolution_description",""))): found["pii_in_free_text"].add(i)
    # Near duplicate text/time similarities are approximated by repeated key dimensions.
    keys_seen=set()
    for i,r in enumerate(rows):
        k=(r.get("created_date"),r.get("complaint_type"),r.get("borough"),r.get("incident_zip"))
        if k in keys_seen or str(r.get("unique_key","")).endswith("-near"): found["near_duplicates"].add(i)
        keys_seen.add(k)
    return found


def _coord_ok(r):
    try:return 40.4<=float(r.get("latitude"))<=41 and -74.3<=float(r.get("longitude"))<=-73.6
    except (ValueError,TypeError):return False
def _zip_mismatch(r):
    z,b=str(r.get("incident_zip","")),str(r.get("borough","")).upper()
    return (b=="MANHATTAN" and not z.startswith(("100","101","102"))) or (b=="BROOKLYN" and not z.startswith("112")) or (b=="QUEENS" and not z.startswith(("110","111","113","114","116")))
def _contradiction(r):
    c,d=str(r.get("complaint_type","")).lower(),str(r.get("descriptor","")).lower()
    return ("noise" in c and ("driveway" in d or "parking" in d)) or ("driveway" in c and "music" in d)


def llm_detector(rows: list[dict], enabled: bool = False) -> dict:
    """Optional Gemini batch review. Returns unavailable without making network calls."""
    if not enabled or not os.getenv("GEMINI_API_KEY"):
        reason="not requested" if not enabled else "GEMINI_API_KEY is not configured"
        return {"available":False,"reason":reason,"alerts":[],"latency_seconds":None}
    # Review only a small bounded sample; return explanations, not a substitute for hard checks.
    from project_a.llm import gemini_json
    sample=rows[:min(20,len(rows))]
    prompt="Review these NYC 311 rows for data-quality anomalies. Return JSON {alerts:[{row_index,problem,reason}]}. Do not infer private data unless visible. Rows="+str(sample)
    result,latency=gemini_json(prompt)
    return {"available":True,"alerts":result.get("alerts",[]),"latency_seconds":latency,"usage":result.get("_usage")}


def hybrid_detector(rows: list[dict]) -> dict[str,set[int]]:
    """Cheap schema/row rules first; statistical batch anomaly union second."""
    rule=rule_detector(rows); stats=statistical_detector(rows)
    return {k:rule[k]|stats[k] for k in rule}
