"""Seeded 12-type corruption injector. Returns a copy and row-level labels."""
import copy, random
from datetime import datetime, timedelta

PROBLEMS = ("renamed_dropped_column", "type_change", "date_format_switch", "swapped_coordinates", "exact_duplicates", "near_duplicates", "agency_null_spike", "closed_before_created", "zip_borough_mismatch", "complaint_descriptor_mismatch", "resolution_status_conflict", "pii_in_free_text")


def clean_rows(n: int = 1000, seed: int = 7) -> list[dict]:
    rng = random.Random(seed)
    result=[]
    for i in range(n):
        created=datetime(2023,1,1)+timedelta(minutes=i)
        result.append({"unique_key": str(500_000_000+i), "created_date": created.isoformat(timespec="seconds"), "closed_date": (created+timedelta(hours=2)).isoformat(timespec="seconds") if i%3 else "", "agency": "NYPD" if i%2 else "DOT", "complaint_type": "Noise - Residential" if i%2 else "Blocked Driveway", "descriptor": "Loud Music/Party" if i%2 else "No Access", "status": "Closed" if i%3 else "Open", "resolution_description": "The condition was corrected." if i%3 else "", "borough": "BROOKLYN" if i%2 else "QUEENS", "incident_zip": "11201" if i%2 else "11101", "latitude": round(40.6+rng.random()*.2, 6), "longitude": round(-74.0+rng.random()*.2, 6)})
    return result


def inject(rows: list[dict], problem: str, rate: float = .05, seed: int = 11) -> tuple[list[dict], set[int]]:
    out=copy.deepcopy(rows); rng=random.Random(seed); k=max(1, int(len(out)*rate)); indices=set(rng.sample(range(len(out)), min(k,len(out))))
    if problem == "renamed_dropped_column":
        for row in out: row.pop("borough", None)
        indices=set(range(len(out)))
    elif problem == "type_change":
        for row in out: row["incident_zip"] = int(row["incident_zip"])
        indices=set(range(len(out)))
    elif problem == "date_format_switch":
        for i in sorted(indices): out[i]["created_date"] = "06/" + out[i]["created_date"][8:10] + "/2023 12:00 PM"
    elif problem == "swapped_coordinates":
        for i in indices: out[i]["latitude"],out[i]["longitude"] = out[i]["longitude"],out[i]["latitude"]
    elif problem == "exact_duplicates":
        out.extend(copy.deepcopy(out[i]) for i in sorted(indices))
        indices=set(range(len(rows), len(out)))
    elif problem == "near_duplicates":
        for i in sorted(indices):
            twin=copy.deepcopy(out[i]); twin["unique_key"] += "-near"; twin["resolution_description"] += " "; out.append(twin)
        indices=set(range(len(rows), len(out)))
    elif problem == "agency_null_spike":
        for i in indices: out[i]["agency"] = ""
    elif problem == "closed_before_created":
        for i in indices: out[i]["closed_date"] = "2022-05-01T10:00:00.000"
    elif problem == "zip_borough_mismatch":
        for i in indices: out[i]["incident_zip"],out[i]["borough"] = "10001","BROOKLYN"
    elif problem == "complaint_descriptor_mismatch":
        for i in indices: out[i]["complaint_type"],out[i]["descriptor"] = "Noise - Residential","Blocked Driveway - No Access"
    elif problem == "resolution_status_conflict":
        for i in indices: out[i]["status"],out[i]["resolution_description"] = "Open","The issue was resolved and closed."
    elif problem == "pii_in_free_text":
        for i in indices: out[i]["resolution_description"] = "Call Jane Doe at 212-555-0198 or jane@example.com."
    else: raise ValueError(problem)
    return out, indices
