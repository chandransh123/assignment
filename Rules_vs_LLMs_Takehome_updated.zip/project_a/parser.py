"""Small auditable parser. Unsupported or conflicting details produce questions."""
import re
from dataclasses import dataclass
from .tax import Taxpayer


@dataclass(frozen=True)
class ParseResult:
    taxpayer: Taxpayer | None
    questions: tuple[str, ...]
    notes: tuple[str, ...] = ()


def parse_description(text: str) -> ParseResult:
    s = text.lower().replace(",", "")
    amounts = [int(x.replace(" ", "")) for x in re.findall(r"(?:₹|rs\.?|inr)\s*(\d[\d ]*)", s)]
    salary_match = re.search(r"(?:salary|earn(?:ing|s)?|income)\D{0,20}(?:₹|rs\.?|inr)?\s*([\d ]+)\s*(lakh|lac|k|thousand)?", s)
    salary = None
    if salary_match:
        n = int(salary_match.group(1).replace(" ", ""))
        unit = (salary_match.group(2) or "").lower()
        salary = n * (100_000 if unit in ("lakh", "lac") else 1_000 if unit in ("k", "thousand") else 1)
    # Explicitly detect multiple amounts near salary as a possible contradiction.
    if salary is None and len(amounts) == 1:
        salary = amounts[0]
    if salary is None:
        return ParseResult(None, ("What is your annual gross salary (before deductions), in rupees?",))
    if "per month" in s or "monthly" in s or "each month" in s:
        return ParseResult(None, ("Is that amount monthly or annual? Please give annual gross salary before deductions.",))
    contradictions = ("not resident" in s and ("resident india" in s or "indian resident" in s))
    if contradictions:
        return ParseResult(None, ("You described yourself as both resident and non-resident. Which is correct for Indian tax purposes?",))
    if re.search(r"\b(?:but also|also according to|either|or maybe)\b", s) and len(re.findall(r"\d[\d ]*", s)) > 1:
        return ParseResult(None, ("You gave conflicting income figures. Which amount is your annual gross salary, and what explains the other figure?",))
    questions = []
    age_m = re.search(r"\bage\s*(\d{1,3})\b|\b(\d{1,3})\s*(?:years? old|yrs? old)\b", s)
    if not age_m:
        questions.append("What is your age? (It can change old-regime slab thresholds.)")
    has_residency = any(x in s for x in ("resident india", "resident indian", "indian resident", "tax resident", "non-resident", "non resident", "nonresident"))
    if not has_residency:
        questions.append("Are you resident in India for tax purposes for this financial year? (This affects Section 87A eligibility.)")
    if not any(x in s for x in ("no deduction", "no deductions", "nothing to claim", "no hra", "no 80c", "no 80d")) and not any(x in s for x in ("80c", "80d", "hra", "80ccd", "home loan", "home-loan")):
        questions.append("Do you have any HRA exemption, 80C, 80CCD(1B), 80D, or self-occupied home-loan-interest claims? If not, say none.")
    # If caller indicates a deduction but gives no amount, don't silently assume zero.
    for phrase, question in (("80c", "Please provide the Section 80C claim amount."), ("80d", "Please provide Section 80D premium amounts for yourself/family and parents, including parent age 60+ status."), ("hra", "Please provide annual HRA received, rent paid, eligible basic salary/DA, and metro/non-metro city."), ("80ccd", "Please provide the Section 80CCD(1B) contribution amount."), ("home loan", "Please provide interest paid on the self-occupied home loan and confirm eligibility for the deduction.")):
        if phrase in s:
            questions.append(question)
    if questions:
        return ParseResult(None, tuple(questions))
    age_m = re.search(r"\bage\s*(\d{1,3})\b|\b(\d{1,3})\s*(?:years? old|yrs? old)\b", s)
    age = int(next(x for x in age_m.groups() if x)) if age_m else 30
    # Conservative ambiguity: don't infer residence from nationality or location wording.
    resident = not any(x in s for x in ("non resident", "non-resident", "nonresident"))
    return ParseResult(Taxpayer(gross_salary=salary, age=age, resident=resident), (), ("Amounts and deduction claims beyond annual salary are not inferred by this baseline parser.",))
