# Project B — Results

## Synthetic benchmark

Seeded batches: 1000 clean rows; row-level corruptions are injected at 5%. Column-name and type-change anomalies apply to the whole batch. This is one seeded run against checks designed for those patterns, not evidence of performance on the full NYC data distribution.

| Problem | Rules recall / clean FAR | Statistics recall / clean FAR | Hybrid recall / clean FAR |
|---|---:|---:|---:|
| `renamed_dropped_column` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `type_change` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `date_format_switch` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `swapped_coordinates` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `exact_duplicates` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `near_duplicates` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `agency_null_spike` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `closed_before_created` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `zip_borough_mismatch` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `complaint_descriptor_mismatch` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `resolution_status_conflict` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |
| `pii_in_free_text` | 100% / 0.0% | 100% / 0.0% | 100% / 0.0% |

## Latency, throughput and costs

| Family | Clean-batch false alerts | Median injected-batch throughput | Direct cost / million rows |
|---|---:|---:|---:|
| rules | 0 | 74,528 rows/s | $0 direct API; compute excluded |
| statistics | 0 | 45,908 rows/s | $0 direct API; compute excluded |
| hybrid | 0 | 31,164 rows/s | $0 direct API; compute excluded |
| LLM sample review | Not run | Not measured | Not measured |

## Live-data profile and limitations

The provided profiler reads a local 2023 CSV export or queries Socrata through `project_b.data.fetch_2023`. The execution environment could not reach the NYC Open Data endpoint, so real-data issue counts/examples are **not measured**. Do not substitute synthetic counts for NYC findings. Record export time, row count and exact query when profiling; the source updates over time.

The LLM detector reviews up to 20 sampled rows and is opt-in. It was not run because the Gemini API was unreachable from the execution environment, so its detection, false alarms, latency and spend are not measured. Local throughput is from this execution container, not a named laptop. `$0` is only direct LLM/API spend for deterministic code; it excludes CPU, storage, engineering and operations.

## Hybrid pipeline and scale design

Run schema checks and deterministic row rules on ingest; aggregate null rates, category drift and duplicate signatures per batch; send only a small sample of unresolved semantic contradictions to a reviewer. Keep PII detection on every row with a strict privacy path and avoid sending raw text to an external model unless policy permits it. Partition by customer/schema version, stream cheap checks, maintain sketches/counters, and use queues for flagged samples.

At an even split, 50M rows/day is 416,667 rows/customer/day. A straight-line extrapolation from this run's median hybrid throughput (21,532 rows/s) is about 38.7 single-worker minutes/day. This is a lower-bound extrapolation with no I/O, skew, concurrency, model calls or production overhead; it is not a capacity commitment. Benchmark representative hardware before sizing.

## Source

- [NYC 311 Service Requests from 2020 to Present](https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2020-to-Present/erm2-nwe9)
