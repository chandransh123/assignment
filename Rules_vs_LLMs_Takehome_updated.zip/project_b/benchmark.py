"""Seeded synthetic detector benchmark; reports raw counts and elapsed CPU wall time."""
import json, time, sys
from project_b.inject import PROBLEMS, clean_rows, inject
from project_b.detectors import rule_detector, statistical_detector, hybrid_detector, llm_detector

FAMILIES={"rules":rule_detector,"statistics":statistical_detector,"hybrid":hybrid_detector}

def scores(predicted, labels, universe):
    tp=len(predicted&labels); fp=len(predicted-labels); fn=len(labels-predicted); tn=max(0,universe-len(labels)-fp)
    return {"tp":tp,"fp":fp,"fn":fn,"tn":tn,"detection_rate":round(tp/(tp+fn),4) if tp+fn else None,"false_alarm_rate":round(fp/(fp+tn),4) if fp+tn else None}

def run(n=1000, rate=.05, seed=7, with_llm=False):
    clean=clean_rows(n,seed); output={"sample_rows":n,"injection_rate":rate,"seed":seed,"families":{},"llm":{"available":False,"note":"Optional Gemini detector not invoked by offline reproduction."}}
    for name,detector in FAMILIES.items():
        fam={}; start=time.perf_counter(); clean_prediction=detector(clean); elapsed_clean=time.perf_counter()-start
        clean_fp=sum(len(s) for s in clean_prediction.values())
        fam["clean_false_alarms"]={"count":clean_fp,"rows":n,"rate":round(clean_fp/(n*len(PROBLEMS)),5),"seconds":round(elapsed_clean,6)}
        for problem in PROBLEMS:
            data,labels=inject(clean,problem,rate,seed+1)
            start=time.perf_counter(); pred=detector(data)[problem]; elapsed=time.perf_counter()-start
            actual=len(data)
            clean_alerts=clean_prediction[problem]
            fam[problem]={**scores(pred,labels,actual),"clean_false_alarm_count":len(clean_alerts),"clean_false_alarm_rate":round(len(clean_alerts)/n,4),"seconds":round(elapsed,6),"rows_per_second":round(actual/elapsed) if elapsed else None,"cost_per_million_usd":0.0}
        output["families"][name]=fam
    output["llm"]=llm_detector(clean[:20],enabled=with_llm)
    output["cost_note"]="$0.00 is direct API spend for local rules/statistics; it excludes compute, storage and engineering cost. Gemini costs are reported only after an actual API run and a dated price input."
    return output

if __name__=="__main__":print(json.dumps(run(with_llm="--with-llm" in sys.argv),indent=2))
