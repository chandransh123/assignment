# AI usage note

- ChatGPT was used to read the assignment, draft the Python implementation, create synthetic edge cases, and review the resulting measurements.
- The user supplied a Gemini key for measurement. A single minimal API request was attempted from the provided execution environment, but the connection timed out before Gemini returned a response; no model output or usage data was received. The key is not included in this project. `scripts/benchmark_gemini.py` is prepared for 100 sequential query-time calls from an environment that can reach the Gemini API. The optional compiled-rule-candidate and NYC batch-review paths have not produced measured results.
- The tax rules file in this project is a reviewed, hand-entered configuration. It was not produced by the Gemini compiler. The compiler writes a pending candidate and does not activate it.
- One AI-generated mistake was the first borough ZIP prefix heuristic: it treated valid Queens ZIP codes beginning with `11` as mismatches. A clean seeded batch surfaced the false alarms; the prefix mapping was corrected and the synthetic benchmark rerun. The final simple prefix check still needs an authoritative ZIP/borough crosswalk before production.

The Gemini adapter uses Google's documented Interactions API and structured JSON output ([API guide](https://ai.google.dev/gemini-api/docs/get-started), [pricing](https://ai.google.dev/gemini-api/docs/pricing/)). Model names, free-tier availability and quotas can change; capture the model version, usage metadata, and dated pricing at experiment time.
