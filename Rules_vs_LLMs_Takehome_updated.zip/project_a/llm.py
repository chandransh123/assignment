"""Optional Gemini REST adapter; kept opt-in so offline runs remain reproducible."""
import json, os, time, urllib.request


def gemini_json(prompt: str) -> tuple[dict, float]:
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("Set GEMINI_API_KEY to run an actual Gemini experiment")
    model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    url = "https://generativelanguage.googleapis.com/v1beta/interactions"
    body = {"model": model, "input": prompt, "response_format": {"type":"text","mime_type":"application/json","schema":{"type":"object"}}}
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", "x-goog-api-key": key}, method="POST")
    start = time.perf_counter()
    with urllib.request.urlopen(req, timeout=60) as response:
        payload = json.loads(response.read())
    elapsed = time.perf_counter() - start
    output = payload.get("output_text")
    if not output:
        for step in payload.get("steps",[]):
            if step.get("type")=="model_output":
                output="".join(part.get("text","") for part in step.get("content",[]) if part.get("type")=="text")
    if not output: raise ValueError("Gemini response did not contain JSON output text")
    result=json.loads(output)
    if isinstance(payload.get("usage"),dict): result["_usage"]=payload["usage"]
    return result, elapsed


def query_time_tax(description: str, rule_text: str) -> tuple[dict, float]:
    prompt = ("Use only supplied rules. If facts are missing/ambiguous, return {\\\"questions\\\":[...]}. "
              "Otherwise return JSON with extracted salary facts and old/new tax totals. Do not invent facts.\n"
              f"RULE TEXT:\n{rule_text}\nUSER:\n{description}")
    return gemini_json(prompt)


def llm_compiled_rules(rule_text: str) -> tuple[dict, float]:
    prompt = ("Compile these tax rules into a JSON rule table with slabs, deductions, rebates, surcharge and cess. "
              "Return only JSON. A human must review the output before activation.\n" + rule_text)
    return gemini_json(prompt)
