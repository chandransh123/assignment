"""Offline repeatability/latency benchmark for deterministic rule paths."""
import csv, json, statistics, time
from pathlib import Path
from project_a.tax import Taxpayer, calculate
from project_a.approaches import _compiled

def run():
    with open(Path(__file__).with_name("test_cases.csv"),newline="") as f: cases=list(csv.DictReader(f))
    compiled=_compiled(); result={"cases":len(cases),"repeats_per_case":10,"implementations":{}}
    for name,rules in (("hand_coded",None),("compiled_config",compiled)):
        outputs=[]; durations=[]; correct=0
        for row in cases:
            person=Taxpayer(int(row["gross_salary"]))
            for regime in ("old","new"):
                expected=int(row[regime+"_expected"])
                run_tax=[]
                for _ in range(10):
                    start=time.perf_counter(); actual=calculate(person,regime,row["assessment_year"],rules).total_tax; durations.append(time.perf_counter()-start); run_tax.append(actual)
                correct+=int(run_tax[0]==expected)
                outputs.append(run_tax)
        result["implementations"][name]={"comparisons":len(cases)*2,"exact_matches":correct,"accuracy":correct/(len(cases)*2),"deterministic_10_repeats":all(len(set(x))==1 for x in outputs),"median_latency_ms":round(statistics.median(durations)*1000,5),"p95_latency_ms":round(sorted(durations)[int(.95*(len(durations)-1))]*1000,5),"cost_per_1000_usd":0.0}
    official_path=Path(__file__).with_name("official_calculator_checks.csv")
    with open(official_path,newline="") as f: official=list(csv.DictReader(f))
    mismatches=[]
    for row in official:
        income=int(row["taxable_income"]); year=row["assessment_year"]
        for regime,deduction,column in (("old",50_000,"old_tax_official"),("new",75_000,"new_tax_official")):
            actual=calculate(Taxpayer(income+deduction),regime,year).total_tax
            expected=int(row[column])
            if actual!=expected:mismatches.append({"taxable_income":income,"regime":regime,"official":expected,"engine":actual,"difference":actual-expected})
    result["official_calculator"]={"assessment_year":"AY2025-26","input_cases":len(official),"regime_comparisons":len(official)*2,"exact_matches":len(official)*2-len(mismatches),"mismatches":mismatches,"details_file":"project_a/official_validation.md"}
    result["implementations"]["query_time_llm"]={"status":"not_run","reason":"Gemini was not invoked; calls require an API key and results depend on model/version.","accuracy":None,"deterministic_10_repeats":None,"latency_ms":None,"cost_per_1000_usd":None}
    result["note"]="Fixtures cover pure salary scenarios. They do not verify deductions, HRA, surcharge against the official portal, or LLM output. API cost needs dated Gemini pricing and actual usage metadata."
    return result

if __name__=="__main__":print(json.dumps(run(),indent=2))
