"""NYC 311 sampling and profiling helpers (stdlib only)."""
import csv, json, os, re, urllib.parse, urllib.request
from collections import Counter
from datetime import datetime

DATASET_ID = "erm2-nwe9"
API = f"https://data.cityofnewyork.us/resource/{DATASET_ID}.json"

def fetch_2023(limit: int = 5000, offset: int = 0) -> list[dict]:
    query = {"$where": "created_date >= '2023-01-01T00:00:00' AND created_date < '2024-01-01T00:00:00'", "$limit": limit, "$offset": offset, "$order": "unique_key"}
    req = urllib.request.Request(API + "?" + urllib.parse.urlencode(query), headers={"User-Agent": "rules-vs-llms-takehome/0.1"})
    with urllib.request.urlopen(req, timeout=60) as response: return json.loads(response.read())

def fetch_all_2023(page_size: int = 50000) -> list[dict]:
    """Page through all matching rows; requires public Socrata access."""
    rows=[]; offset=0
    while True:
        page=fetch_2023(min(page_size,50000),offset); rows.extend(page)
        if len(page)<page_size: return rows
        offset+=len(page)

def load_csv(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f: return list(csv.DictReader(f))

def profile(rows: list[dict]) -> dict:
    if not rows: return {"rows":0,"error":"empty dataset"}
    keys=list(rows[0]); nulls={k:sum(not str(r.get(k,"")).strip() for r in rows) for k in keys}
    dates=[]; seen_ids=set(); seen_rows=set(); issues={k:[] for k in ("bad_created_date","closed_before_created","outside_nyc_coordinate_box","duplicate_unique_key","exact_duplicate_row","zip_borough_mismatch","complaint_descriptor_inconsistent","resolution_status_inconsistent","possible_pii_in_free_text")}
    pii=re.compile(r"(?:\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b|\b(?:\+?1[-. ]?)?\(?\d{3}\)?[-. ]\d{3}[-. ]\d{4}\b)")
    for row in rows:
        key=row.get("unique_key")
        try:
            created=datetime.fromisoformat(str(row.get("created_date","")).replace("Z","+00:00")); dates.append(created.date().isoformat())
            closed_s=str(row.get("closed_date","")).strip()
            if closed_s and datetime.fromisoformat(closed_s.replace("Z","+00:00"))<created:
                issues["closed_before_created"].append({"unique_key":key,"created_date":row.get("created_date"),"closed_date":closed_s})
        except (ValueError,TypeError): issues["bad_created_date"].append({"unique_key":key,"created_date":row.get("created_date")})
        try:
            lat,lon=float(row.get("latitude","")),float(row.get("longitude",""))
            if not (40.4<=lat<=41.0 and -74.3<=lon<=-73.6): issues["outside_nyc_coordinate_box"].append({"unique_key":key,"latitude":lat,"longitude":lon})
        except (ValueError,TypeError): pass
        if key and key in seen_ids: issues["duplicate_unique_key"].append({"unique_key":key})
        if key: seen_ids.add(key)
        signature=tuple(sorted((str(k),str(v)) for k,v in row.items()))
        if signature in seen_rows: issues["exact_duplicate_row"].append({"unique_key":key})
        seen_rows.add(signature)
        borough=str(row.get("borough","")).upper(); z=str(row.get("incident_zip","") or "")
        mismatch=(borough=="MANHATTAN" and not z.startswith(("100","101","102"))) or (borough=="BROOKLYN" and not z.startswith("112")) or (borough=="QUEENS" and not z.startswith(("110","111","113","114","116")))
        if borough and z and mismatch: issues["zip_borough_mismatch"].append({"unique_key":key,"borough":borough,"incident_zip":z})
        complaint=str(row.get("complaint_type","")).lower(); descriptor=str(row.get("descriptor","")).lower()
        if ("noise" in complaint and ("driveway" in descriptor or "parking" in descriptor)) or ("driveway" in complaint and "music" in descriptor):
            issues["complaint_descriptor_inconsistent"].append({"unique_key":key,"complaint_type":row.get("complaint_type"),"descriptor":row.get("descriptor")})
        resolution=str(row.get("resolution_description","")).lower()
        if str(row.get("status","")).lower()=="open" and any(w in resolution for w in ("resolved","corrected","closed")):
            issues["resolution_status_inconsistent"].append({"unique_key":key,"status":row.get("status"),"resolution_description":row.get("resolution_description")})
        if pii.search(str(row.get("descriptor",""))+" "+str(row.get("resolution_description",""))):
            issues["possible_pii_in_free_text"].append({"unique_key":key,"fields":"descriptor/resolution_description"})
    null_by_agency={}
    agencies=sorted({str(r.get("agency") or "<null>") for r in rows})
    for agency in agencies:
        subset=[r for r in rows if str(r.get("agency") or "<null>")==agency]
        null_by_agency[agency]={field:sum(not str(r.get(field,"")).strip() for r in subset) for field in keys if field not in ("agency","unique_key")}
    return {"rows":len(rows),"columns":keys,"null_counts":nulls,"null_counts_by_agency":null_by_agency,
            "created_date_min":min(dates) if dates else None,"created_date_max":max(dates) if dates else None,
            "issue_counts":{name:len(items) for name,items in issues.items()},"issue_examples":{name:items[:5] for name,items in issues.items() if items},
            "top_complaints":Counter(r.get("complaint_type","") for r in rows).most_common(10),
            "top_agencies":Counter(r.get("agency","") for r in rows).most_common(10)}

if __name__ == "__main__":
    path=os.getenv("NYC_CSV")
    if not path: raise SystemExit("Set NYC_CSV to a local 2023 CSV export; see README.md")
    print(json.dumps(profile(load_csv(path)),indent=2,default=list))
