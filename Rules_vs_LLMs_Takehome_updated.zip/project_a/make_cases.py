"""Independent pure-salary oracle for the checked-in 200-case boundary fixture."""
import csv
from pathlib import Path

OLD=[(250000,0),(500000,.05),(1000000,.20),(None,.30)]
NEW24=[(300000,0),(700000,.05),(1000000,.10),(1200000,.15),(1500000,.20),(None,.30)]
NEW25=[(400000,0),(800000,.05),(1200000,.10),(1600000,.15),(2000000,.20),(2400000,.25),(None,.30)]

def slabs(amount, bands):
    total=0; prior=0
    for cap,rate in bands:
        end=amount if cap is None else min(amount,cap)
        total+=(end-prior)*rate
        if cap is None or amount<=cap: break
        prior=cap
    return int(total+.5)

def expected(gross, regime, year):
    standard=min(gross,50000 if regime=="old" else 75000)
    raw_income=max(0,gross-standard)
    taxable=((raw_income+5)//10)*10
    if regime=="old":
        tax=slabs(taxable,OLD); limit,cap=500000,12500
    else:
        tax=slabs(taxable,NEW24 if year=="AY2025-26" else NEW25)
        limit,cap=(700000,25000) if year=="AY2025-26" else (1200000,60000)
    rebate=min(tax,cap) if raw_income<=limit else min(cap,max(0,tax-(raw_income-limit)))
    tax=max(0,tax-rebate)
    if taxable<=5000000: sur=0
    else:
        rate=.10 if taxable<=10000000 else .15 if taxable<=20000000 else .25
        if regime=="old" and taxable>50000000: rate=.37
        sur=int(tax*rate+.5)
        threshold=5000000 if taxable<=10000000 else 10000000 if taxable<=20000000 else 20000000 if regime=="new" or taxable<=50000000 else 50000000
        tr=.10 if threshold==5000000 else .15 if threshold==10000000 else .25 if threshold==20000000 else .37
        base_at=slabs(threshold, OLD if regime=="old" else NEW24 if year=="AY2025-26" else NEW25)
        sur=min(sur,max(0,base_at+int(base_at*tr+.5)+(taxable-threshold)-tax))
    cess=int((tax+sur)*.04+.5)
    return ((tax+sur+cess+5)//10)*10

def build(path=None):
    thresholds=[250000,300000,400000,500000,700000,800000,1000000,1200000,1500000,1600000,2000000,2400000,5000000,10000000,20000000,50000000]
    incomes={0,1,49999,50000,50001,74999,75000,75001,249999,250000,250001,499999,500000,500001,699999,700000,700001,1199999,1200000,1200001,1275000,1499999,1500000,1500001,1999999,2000000,2000001,2399999,2400000,2400001,4999999,5000000,5000001,9999999,10000000,10000001,19999999,20000000,20000001,49999999,50000000,50000001,100000000}
    for t in thresholds:
        incomes.update((max(0,t-1),t,t+1))
    # Deterministic values fill the fixture to 200 distinct integer incomes.
    n=100000
    while len(incomes)<100:
        incomes.add(n); n+=7919
    rows=[]
    for year in ("AY2025-26","AY2026-27"):
        for gross in sorted(incomes):
            rows.append({"assessment_year":year,"gross_salary":gross,"old_expected":expected(gross,"old",year),"new_expected":expected(gross,"new",year)})
    # 2 years x 100 inputs = 200 test fixtures; expected values are independent of tax.calculate.
    path=path or Path(__file__).with_name("test_cases.csv")
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    return len(rows)

if __name__=="__main__": print(build())
