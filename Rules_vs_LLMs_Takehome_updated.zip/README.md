# Rules vs LLMs — take-home implementation

Python 3.10+ reference project for the two tasks in the supplied assignment. It is designed to run offline for the deterministic paths; Gemini calls are opt-in and require `GEMINI_API_KEY`.

## Run

```bash
python -m venv .venv && . .venv/bin/activate
pip install -e .
python scripts/reproduce.py
```

`reproduce.py` runs the test suite, creates 200 generated tax boundary fixtures, injects the 12 listed corruptions into a seeded NYC-shaped sample, benchmarks the three detector families, and rewrites the result tables. This reproduces local synthetic measurements. It does not claim that synthetic data equals the live NYC dataset or that the official Income Tax Department calculator has been queried.

To download and profile real NYC 311 data, run `python -m project_b.download --out data/nyc_311_2023.csv`, then `NYC_CSV=data/nyc_311_2023.csv python -m project_b.data`. The downloader writes a metadata sidecar with the source and retrieval time. The Socrata source updates, so preserve that provenance with any report. Optional Gemini calls use Google's Interactions API and can be enabled for explicit experiments with `GEMINI_API_KEY` and `python -m project_b.benchmark --with-llm`; they are never needed for local reproduction.

For the Project A query-time comparison, set `GEMINI_API_KEY` in the shell environment and run `python scripts/benchmark_gemini.py`. This makes 100 sequential requests (10 complete salary descriptions, each repeated 10 times) and writes per-call observations and a summary under `results/`. The script does not save or print the key. It estimates paid-tier cost from token usage and configurable per-million-token prices; only the account's billing/quota page can confirm whether calls were covered by free quota. Do not commit a key or `.env` file.

## Important scope

This is a take-home prototype, not tax advice or a filing product. Inputs deliberately exclude special-rate income, rebates/surcharges associated with special income, non-salary income, and tax interest. Tax rounding follows total-income/tax rounding to the nearest ₹10. HRA and eligible salary components are caller supplied. Thirty official advanced-calculator inputs are recorded in `project_a/official_calculator_checks.csv`; 49 of 60 regime outputs match exactly, with the remaining portal rounding differences documented in `project_a/official_validation.md`. Resolve those differences and expand the deduction checks before production use.

## Layout

- `project_a/`: deterministic tax engine, free-text clarification parser, Gemini adapters, FY 2024-25 and FY 2025-26 parameters, boundary fixtures.
- `project_b/`: NYC CSV profiler, seeded corruption injector, rule/statistical/LLM detector interfaces, hybrid pipeline, benchmark harness.
- `tests/`: unit and regression tests.
- `RESULTS_A.md`, `RESULTS_B.md`, `DECISION_MATRIX.md`, `AI_USAGE.md`: assignment reports.
